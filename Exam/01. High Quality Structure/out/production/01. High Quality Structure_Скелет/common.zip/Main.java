import entities.*;

import core.interfaces.MachineFactory;
import core.interfaces.PilotFactory;
import core.interfaces.MachinesManager;
import entities.interfaces.Machine;
import entities.interfaces.Pilot;


import java.util.LinkedHashMap;
import java.util.Map;

public class Main {


    public static void main(String[] args) {
        

        //PilotImpl pilot = (PilotImpl) pilotClass.getDeclaredConstructor(String.class).newInstance("Pesho");
        Pilot pilot = new PilotImpl("Pesho");



        MachineFactory machineFactory = null; //TODO change null with your implementation
        Map<String, Pilot> pilots = new LinkedHashMap<>();
        Map<String, Machine> machines = new LinkedHashMap<>();
       // MachinesManager machinesManager = new MachinesManagerImpl(pilotFactory, machineFactory, pilots, machines);
        Machine machine = new TankImpl("22",12,23);
        //System.out.println(machine.getHealthPoints());
    }
}
