package entities;

import entities.interfaces.Tank;

public class TankImpl extends BaseMachine implements Tank {
    private boolean defenseMode;
    private static final double attackPointsModifier = 40.0;
    private static final double deffencePointsModifier = 30.0;


    public TankImpl(String name, double attackPoints, double defensePoints) {
        super(name, attackPoints, defensePoints, 200);
        this.defenseMode = true;
    }

    @Override
    public boolean getDefenseMode() {
        return defenseMode;
    }

    @Override
    public void toggleDefenseMode() {
        if (defenseMode) {
            defenseMode = false;
        }else {
            defenseMode = true;
        }
    }

    @Override
    public String toString() {
        String aggMode = "";
        if (defenseMode == true) {
            aggMode = "ON";
        } else {
            aggMode = "OFF";
        }

        String targets = "";
        if (getTargets() == null) {
            targets = "None";
        } else {
            targets = String.join(", ", getTargets());
        }
        return String.format("*Type: Tank \n" +
                " *Health: %.2f\n" +
                " *Attack: %.2f\n" +
                " *Defense: %.2f\n" +
                " *Targets: %s\n" +
                " *Defense Mode(%s)", this.getAttackPoints(), this.getDefensePoints(), this.getTargets(),aggMode);
    }
}
