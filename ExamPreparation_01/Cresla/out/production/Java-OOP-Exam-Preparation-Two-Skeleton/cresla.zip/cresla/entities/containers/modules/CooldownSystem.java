package cresla.entities.containers.modules;

public class CooldownSystem extends AbsorbingModuleImpl {

    public CooldownSystem(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }
}
