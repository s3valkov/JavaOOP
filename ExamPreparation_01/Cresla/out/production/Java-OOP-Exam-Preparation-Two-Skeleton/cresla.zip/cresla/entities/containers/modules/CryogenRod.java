package cresla.entities.containers.modules;

public class CryogenRod extends EnergyModuleImpl {


    public CryogenRod(int id, int energyOutput) {
        super(id, energyOutput);
    }
}
