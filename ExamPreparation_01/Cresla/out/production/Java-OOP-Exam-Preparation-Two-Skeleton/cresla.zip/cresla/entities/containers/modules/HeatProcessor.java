package cresla.entities.containers.modules;

public class HeatProcessor extends AbsorbingModuleImpl {


    public HeatProcessor(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }
}
