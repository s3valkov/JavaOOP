package hell.entities.miscellaneous.heroes;

public class Wizard extends BaseHero {
    public Wizard(String name) {
        super(name, 25, 25, 100, 100, 250);
    }
}
