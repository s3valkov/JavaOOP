package hell;

import hell.interfaces.Hero;
import hell.interfaces.Manager;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Manager manager = new ManagerImpl();


        String command = scanner.nextLine();

        while (!command.equals("Quit")) {
            String result = "";
            String[] commandArgs = command.split(" ");
            switch (commandArgs[0]) {
                case "Hero":
                    result = manager.addHero(Arrays.asList(commandArgs[1], commandArgs[2]));
                    break;
            }
            System.out.println(result);

            command = scanner.nextLine();
        }
    }
}