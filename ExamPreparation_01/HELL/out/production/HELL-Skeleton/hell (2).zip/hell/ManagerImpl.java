package hell;

import hell.entities.miscellaneous.heroes.Assassin;
import hell.entities.miscellaneous.heroes.Barbarian;
import hell.entities.miscellaneous.heroes.Wizard;
import hell.interfaces.Hero;
import hell.interfaces.Manager;

import javax.naming.NamingEnumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

public class ManagerImpl implements Manager {
    private HashMap<String, Hero> localHeroes;

    public ManagerImpl() {
        this.localHeroes = new HashMap<>();
    }

    @Override
    public String addHero(List<String> arguments) {
        Hero result = null;
        String name = arguments.get(0);
        String type = arguments.get(1);
        switch (type) {
            case "Barbarian":
                result = new Barbarian(name);
                break;
            case "Assassin":
                result = new Assassin(name);
                break;
            case "Wizard":
                result = new Wizard(name);
                break;
        }
        localHeroes.put(name, result);

        return String.format("Created %s - %s", type, name);


    }

    @Override
    public String addItem(List<String> arguments) {
        return null;
    }

    @Override
    public String addRecipe(List<String> arguments) {
        return null;
    }

    @Override
    public String inspect(List<String> arguments) {
        return null;
    }

    @Override
    public String quit() {
        return null;
    }
}
