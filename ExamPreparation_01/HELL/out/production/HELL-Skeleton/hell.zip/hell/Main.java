package hell;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String command = scanner.nextLine();

        while (!command.equals("Quit")){
            String[] commandArgs = command.split(" ");
            String commandName = commandArgs[0];





            command = scanner.nextLine();
        }
    }
}