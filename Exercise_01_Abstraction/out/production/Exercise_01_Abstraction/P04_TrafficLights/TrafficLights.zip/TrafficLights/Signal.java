package TrafficLights;

public enum Signal {
    RED,
    YELLOW,
    GREEN,

}
