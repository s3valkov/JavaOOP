package P05_PizzaCalories;

public class Main {
    public static void main(String[] args) {

    }
}
