package P06_FootballTeamGenerator;

public class Main {
    public static void main(String[] args) {
        
    }
}
