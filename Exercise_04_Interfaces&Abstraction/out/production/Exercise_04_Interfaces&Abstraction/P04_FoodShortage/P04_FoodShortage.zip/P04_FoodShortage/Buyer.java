package P04_FoodShortage;

public interface Buyer {
    void buyFood();
    int getFood();
}
