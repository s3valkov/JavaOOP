package P04_FoodShortage;

public interface Identifiable {
    String getId();
}
