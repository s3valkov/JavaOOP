package P04_FoodShortage;

public class Main {
}
