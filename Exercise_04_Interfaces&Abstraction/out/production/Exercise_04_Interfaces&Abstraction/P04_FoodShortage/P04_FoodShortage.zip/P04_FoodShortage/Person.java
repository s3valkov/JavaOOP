package P04_FoodShortage;

public interface Person {
    String getName();

    int getAge();
}
