package P06_MilitaryElite.interfaces;

import java.util.Set;

public interface Commando {
    Set<Mission> missions();

}
