package P06_MilitaryElite.interfaces;

import java.util.Set;

public interface Engineer {
    Set<Repair> getRepairs();
}
