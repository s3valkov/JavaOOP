package P06_MilitaryElite.interfaces;

public interface Private extends Soldier,Comparable<Private> {
    double getSalary();
}
