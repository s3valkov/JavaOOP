package P06_MilitaryElite.interfaces;

public interface Repair {
    String getPartName();
    int getHoursWorked();

}
