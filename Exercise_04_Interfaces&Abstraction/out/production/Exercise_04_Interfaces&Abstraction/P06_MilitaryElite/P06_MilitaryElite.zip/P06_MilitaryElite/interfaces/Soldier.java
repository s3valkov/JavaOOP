package P06_MilitaryElite.interfaces;

public interface Soldier {
    String getId();
    String getFirstName();
    String getLastName();
}
