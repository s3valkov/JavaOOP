package P06_MilitaryElite.models;

import P06_MilitaryElite.enums.MissionState;
import P06_MilitaryElite.interfaces.Mission;

public class MissionImpl implements Mission {
    private String codeName;
    private MissionState missionState;

    public MissionImpl(String codeName, MissionState state) {
        this.codeName = codeName;
        this.missionState = state;
    }

    @Override
    public String getCodeName() {
        return this.codeName;
    }

    @Override
    public MissionState getState() {
        return this.missionState;
    }

    @Override
    public void completeMission() {
        this.missionState = MissionState.Finished;

    }

    @Override
    public String toString() {
        return String.format(" Code Name: %s State: %s",
                this.getCodeName(),
                this.getState());
    }


}
