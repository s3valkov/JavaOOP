package P06_MilitaryElite.models;

public class Soldier implements P06_MilitaryElite.interfaces.Soldier {
    private String id;
    private String firstName;
    private String lastName;

    public Soldier( String firstName, String lastName,String id) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.id = id;
    }

    @Override
    public String getId() {
        return this.id;
    }

    @Override
    public String getFirstName() {
        return this.firstName;
    }

    @Override
    public String getLastName() {
        return this.lastName;
    }


    @Override
    public String toString() {
        return String.format("Name: %s %s Id: %s",
                this.getFirstName(),
                this.getLastName(),
                this.getId());
    }
}
