package P06_MilitaryElite.models;

import P06_MilitaryElite.interfaces.Spy;

public class SpyImpl extends Soldier implements Spy {
    private String codeNumber;

    public SpyImpl(String firstName, String lastName, String id,String codeNumber) {
        super(firstName, lastName, id);
        this.codeNumber = codeNumber;
    }

    @Override
    public String getCodeNumber() {
        return this.codeNumber;
    }

    @Override
    public String toString() {
        return super.toString() + System.lineSeparator() + "Code Number: " + this.getCodeNumber();
    }
}
