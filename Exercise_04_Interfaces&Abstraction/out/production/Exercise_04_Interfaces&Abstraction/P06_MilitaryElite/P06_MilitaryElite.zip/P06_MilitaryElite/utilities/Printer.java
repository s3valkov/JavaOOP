package P06_MilitaryElite.utilities;

public class Printer<T> {
    public static String collectionToString(Iterable iterable) {
        StringBuilder sb = new StringBuilder();

        for (Object obj : iterable) {
            sb.append(" ").append(obj).append("\n");
        }

        if (sb.length() > 0) {
            sb.replace(sb.length() - 1, sb.length(), "");
        }

        return sb.toString();

    }
}
