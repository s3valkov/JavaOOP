package P07_CollectionHirarchy;

public class Main {
    public static void main(String[] args) {
        
    }
}
