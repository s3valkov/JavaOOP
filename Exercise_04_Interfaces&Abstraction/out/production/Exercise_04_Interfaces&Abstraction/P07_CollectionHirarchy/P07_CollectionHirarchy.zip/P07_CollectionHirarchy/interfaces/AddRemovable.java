package P07_CollectionHirarchy.interfaces;

public interface AddRemovable extends  Addable {
    String remove();
}
