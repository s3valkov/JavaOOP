package P07_CollectionHirarchy.interfaces;

public interface Addable {
    int add(String str);
}
