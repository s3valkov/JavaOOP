package P07_CollectionHirarchy.interfaces;

public interface MyList extends AddRemovable {
    int getUsed();
}
