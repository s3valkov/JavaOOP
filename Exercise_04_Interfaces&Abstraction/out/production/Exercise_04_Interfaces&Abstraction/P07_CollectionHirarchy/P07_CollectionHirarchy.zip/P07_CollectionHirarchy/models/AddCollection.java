package P07_CollectionHirarchy.models;

import P07_CollectionHirarchy.interfaces.Addable;
import P07_CollectionHirarchy.models.base.Collection;

public class AddCollection extends Collection implements Addable {

    @Override
    public int add(String str) {
        if (!super.hasCapacity()) {
            return -1;
        }
        super.items.add(str);

        return super.items.size() - 1;
    }
}
