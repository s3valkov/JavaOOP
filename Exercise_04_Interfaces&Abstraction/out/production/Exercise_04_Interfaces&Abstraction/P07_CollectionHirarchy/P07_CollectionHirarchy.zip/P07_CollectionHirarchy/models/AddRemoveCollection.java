package P07_CollectionHirarchy.models;

import P07_CollectionHirarchy.interfaces.AddRemovable;
import P07_CollectionHirarchy.models.base.Collection;

public class AddRemoveCollection extends Collection implements AddRemovable {

    @Override
    public String remove() {
        if (super.items.isEmpty()) {
            return null;
        }
        return super.items.remove(super.items.size() - 1);
    }

    @Override
    public int add(String str) {
        if (!hasCapacity()) {
            return -1;
        }

        super.items.add(str);

        return super.items.size() - 1;
    }
}
