package P07_CollectionHirarchy.models;

import P07_CollectionHirarchy.interfaces.MyList;
import P07_CollectionHirarchy.models.base.Collection;

public class MyListImpl extends Collection implements MyList {


    @Override
    public int getUsed() {
        return super.items.size();
    }

    @Override
    public String remove() {
        if (super.items.isEmpty()) {
            return null;
        }

        return super.items.remove(0);
    }

    public int add(String str) {
        if (!super.hasCapacity()) {
            return -1;
        }
        super.items.add(0, str);

        return 0;
    }
}
