package P02_MultipleImplementation;

public interface Birthable {
    String getBirthDate();
}
