package P02_VehiclesExtension;

public class Bus extends Vehicles {

    public Bus(double fuelQuantity, double litersPerKm, double tankCapacity) {
        super(fuelQuantity, litersPerKm, tankCapacity, 1.4);
    }


}
