package P02_VehiclesExtension;


public class Car extends Vehicles {


    public Car(double fuelQuantity, double litersPerKm, double tankCapacity) {
        super(fuelQuantity, litersPerKm, tankCapacity, 0.9);
        this.setLitersPerKm(litersPerKm);
    }

}
