package P03_WildFarm;

import P03_WildFarm.food.Food;

public class Zebra extends Mammal {


    public Zebra(String animalName, String animalType, Double animalWeight, String livingReligion) {
        super(animalName, animalType, animalWeight, livingReligion);
    }

    @Override
    public void makeSound() {
        System.out.println("Zs");
    }


}
