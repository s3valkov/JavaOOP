package P04_Word;

public interface CommandInterface {
    void init();
    void handleInput(String input);
}
