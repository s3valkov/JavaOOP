package pr0304Barracks.contracts;

public interface Attacker {
    
    int getAttackDamage();
}
