package pr0304Barracks.core.factories;

import jdk.jshell.spi.ExecutionControl;
import pr0304Barracks.contracts.Unit;
import pr0304Barracks.contracts.UnitFactory;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class UnitFactoryImpl implements UnitFactory {

    private static final String UNITS_PACKAGE_NAME =
            "pr0304Barracks.models.units.";

    @Override
    public Unit createUnit(String unitType) {
        Class  cl = null;
        try {
            cl = Class.forName(UNITS_PACKAGE_NAME + unitType);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        Constructor<?> constructor = cl.getConstructors()[0];
        constructor.setAccessible(true);
        Unit unit = null;
        try {
            unit = (Unit) constructor.newInstance();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }

        return unit;
    }
}
