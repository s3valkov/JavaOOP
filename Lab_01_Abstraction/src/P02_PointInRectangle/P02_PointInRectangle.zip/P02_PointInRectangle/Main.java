package P02_PointInRectangle;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int[] rectangleCoordinates = Arrays.stream(scanner.nextLine().split(" "))
                .mapToInt(Integer::parseInt)
                .toArray();
        Point top = new Point(rectangleCoordinates[0], rectangleCoordinates[1]);
        Point bottom = new Point(rectangleCoordinates[2], rectangleCoordinates[3]);
        Rectangle rectangle = new Rectangle(top, bottom);

        int counter = Integer.parseInt(scanner.nextLine());

        while (counter-- > 0) {
            int[] pointCoordinate = Arrays.stream(scanner.nextLine().split(" "))
                    .mapToInt(Integer::parseInt)
                    .toArray();
            Point point = new Point(pointCoordinate[0], pointCoordinate[1]);
            System.out.println(rectangle.isInRectagnle(point));
        }
    }
}
