package P03_HierarchialInheritance;

public class Animal {
    public void eat(){
        System.out.println("eating...");
    }
}
