package P03_HierarchialInheritance;

public class Main {
    public static void main(String[] args) {
        Cat cat = new Cat();
        cat.meow();
    }
}
