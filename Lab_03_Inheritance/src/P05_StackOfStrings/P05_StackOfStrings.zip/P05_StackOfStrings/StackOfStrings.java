package P05_StackOfStrings;
import java.util.ArrayList;


public class StackOfStrings {
    private ArrayList<String> container;

    public StackOfStrings() {
        this.container = new ArrayList<>();
    }

    public void push(String item) {
        this.container.add(item);
    }

    public String pop() {
        if (this.isEmpty()) {
            throw new IndexOutOfBoundsException("Cannot pop on empty Stack");
        }
        return this.container.remove(this.container.size() - 1);
    }

    public String peek() {
        if (this.isEmpty()) {
            throw new IndexOutOfBoundsException("Cannot pop on empty Stack");
        }
        return this.container.get(this.container.size() - 1);
    }


    public boolean isEmpty() {
        return this.container.isEmpty();
    }
}
