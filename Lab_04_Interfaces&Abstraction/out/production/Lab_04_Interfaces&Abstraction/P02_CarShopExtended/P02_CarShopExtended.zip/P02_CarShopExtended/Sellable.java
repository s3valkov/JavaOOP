package P02_CarShopExtended;

public interface Sellable extends Car {

    Double getPrice();
}
