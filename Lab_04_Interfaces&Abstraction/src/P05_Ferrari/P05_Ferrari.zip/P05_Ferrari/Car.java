package P05_Ferrari;

public interface Car {

    String brakes();

    String gas();
}
