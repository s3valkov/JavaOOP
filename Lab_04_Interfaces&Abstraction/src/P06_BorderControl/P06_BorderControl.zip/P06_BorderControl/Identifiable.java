package P06_BorderControl;

public interface Identifiable {

    String getId();
}
