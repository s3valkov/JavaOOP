package P06_BorderControl;

public class Main {
    public static void main(String[] args) {
        
    }
}
