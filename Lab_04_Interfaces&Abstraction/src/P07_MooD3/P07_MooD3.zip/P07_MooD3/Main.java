package P07_MooD3;

public class Main {
    public static void main(String[] args) {
//        Archangel archangel = new Archangel("Akasha",5,100);
//        System.out.println(archangel.toString());
//        Demon demon = new Demon("KoHaH",100.0,100);
//        System.out.println(demon.toString());
    }
}
